======
Common
======

Common is a Django library that provides some reusable components.
